/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_accelero.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_tsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_hsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_gyro.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_psensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_magneto.h"
#include "stdio.h"
#include "math.h" //for calculating shift in mag position

#define TEMP_THR 25.0
#define HUM_THR 50.0
#define MAG_THR 0.120
#define GYRO_THR 40.0
#define ACCEL_THR 50.0
#define P_THR 101500.0
#define WARNING 1
#define RESET 0



static void MX_GPIO_Init(void);
//extern void initialise_monitor_handles(void);	// for semi-hosting support (printf)
static void UART1_Init(void);
void ICU_MODE(void);
void NORMAL_MODE(void);
void mode_switch(void);
void flags_reset(void);
void accel_INT_CONFIG(void);

UART_HandleTypeDef huart1;	//for UART1 transmission


char message_print[64]; //array for UART1 transmission
int mag_start = 0;		//mag starting position
int count = 0; // for magnetometer


volatile short int accel_flag, gyro_flag, p_flag, temp_flag, mag_flag, hum_flag;
volatile short int mode;

int button_count = 0;
volatile uint32_t button_t1;
volatile uint32_t button_t2;



//Variables for timers

   // int timer_diff;
   // int count_10s = 10000;
    //int count_1s = 1000;
    //int five_Hz = 200;
    //int ten_Hz = 100;


int main(void)
{
	//initialise_monitor_handles(); // for semi-hosting support (printf)

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();		//must have to use HAL library
	MX_GPIO_Init();	//initialize PB14, pin connected to LED2
	UART1_Init();		//initialize UART1 for Tera term

	/* Peripheral initializations using BSP functions for all sensors*/
	BSP_ACCELERO_Init(); //initiate accelerometer
	BSP_TSENSOR_Init();	// initiate temp sensor
	BSP_HSENSOR_Init(); //initiate hum sensor
	BSP_GYRO_Init(); 	//initiate gyrometer
	BSP_PSENSOR_Init();	//initiate pressure sensor
	BSP_MAGNETO_Init(); //initiate magneto

	//sensor interrupt config
	accel_INT_CONFIG();

	NORMAL_MODE();	//enter normal mode operation


}//int main

void NORMAL_MODE(void){
	/*Array for reading accelerometer*/
		    float accel_data[3];
		    int16_t accel_data_i16[3] = { 0 };	// array to store the x, y and z readings.
		    /*Reading temperature data*/
		    float temp_data;
		    /*Reading humidity data*/
		    float hum_data;
		    /*Reading pressure data*/
		    float p_data;

		    //For LED2 blinking and warning messages timing
		    	volatile uint32_t t1, t2, warn_t1, warn_t2 = (HAL_GetTick());



		    	/*=======================NORMAL MODE========================================================*/
		    	sprintf(message_print, "Entering Normal Mode.\r\n");
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

		    	while (1)
		    	{
		    		//Read Temperature in degrees C
		    	    temp_data = BSP_TSENSOR_ReadTemp();
		    	    if (temp_data > TEMP_THR)
		    	    {
		    	    temp_flag = WARNING;
		    	    }

		    	    //Read Accelerometer
		    	    BSP_ACCELERO_AccGetXYZ(accel_data_i16);		// read accelerometer
		    	    // the function above returns 16 bit integers which are 100 * acceleration_in_m/s2. Converting to float to print the actual acceleration.
		    	    // Divide values by 9.8 to convert to 'g'
		    	    accel_data[0] = ((float)accel_data_i16[0] / 100.0f) / 9.8f;
		    	    accel_data[1] = ((float)accel_data_i16[1] / 100.0f) / 9.8f;
		    	    accel_data[2] = ((float)accel_data_i16[2] / 100.0f) / 9.8f;

		    	    //Read Humidity in %RH
		    	    hum_data = BSP_HSENSOR_ReadHumidity();
		    	    if (hum_data < HUM_THR){
		    	    hum_flag = WARNING;
		    	    }

		    	   // Read Pressure in Pascal
		    	    p_data = BSP_PSENSOR_ReadPressure()*100.0f;
		    	    if (p_data > P_THR ){
		    	    p_flag = WARNING;
		    	    }



		    	    // LED blink at 5Hz if Body temp or Accelerometer > threshold
		    	    if (temp_flag == WARNING || accel_flag == WARNING){
		    	    	if ((t2 - t1) > 200 )
		    	    	 {
		    	    		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_14);
		    	    		t1 = t2;
		    	    	 }

		    	    	else
		    	    	{
		    	    		t2 = (HAL_GetTick()) ;
		    	    	}
		    	    }

		    	    //Switch to ICU mode
		    	    if (hum_flag == WARNING || p_flag == WARNING){
		    	    	    sprintf(message_print, "Check patient's breath!\r\n");
		    	    	    HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	    	    ICU_MODE();		//switch to ICU mode
		    	    	}

		    	    //Warning messages every 10s
		    	    if ((warn_t2 - warn_t1) > 10000){
		    	    	//Falling detected
		    	    	if (accel_flag == WARNING){
		    	    		sprintf(message_print, "Fall detected\r\n");
		    	    		HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	    		}
		    	    	//Body temp too high
		    	    	if (temp_flag == WARNING){
		    	    		sprintf(message_print, "Fever is detected\r\n");
		    	    		HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	    		}


		    	    		warn_t1 = warn_t2;
		    	    }
		    	    else
		    	    {	warn_t2 = HAL_GetTick();
		    	    }

		    	} //while(1)
}



/* ======ICU mode================================================================================*/

void ICU_MODE(void){
	 /*Array for reading accel*/
	    float accel_data[3];
	    int16_t accel_data_i16[3] = { 0 };	// array to store the x, y and z readings.
	    /*Reading temp data*/
	    float temp_data;
	    /*Reading hum data*/
	    float hum_data;
	    /*Reading pressure data*/
	    float p_data;
	    /*Array for reading Mag data*/
	    float mag_data[3];
	    int16_t mag_data_i16[3] = { 0 };
	    float mag_position[3], mag_shift[3];
	    /*Array for reading Gyro data*/
	    float gyro_data[3];
	    int16_t gyro_data_i16[3] = { 0 };
	    float gyro_combine;

	    int counter = 0; //for ICU mode readings display

	    //for readings and warning messages timing
	    volatile uint32_t read_t1, read_t2, display_t1, display_t2 = (HAL_GetTick());


	    sprintf(message_print, "Entering Intensive Care Mode.\r\n");
	    HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

	    while (1)
	{
		    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET); //switch on LED2 all the time

		    /*Sampling every 1s*/
		    if((read_t2 - read_t1) > 1000){
		    	//Read temp in degrees C
		    	temp_data = BSP_TSENSOR_ReadTemp();
		    	if (temp_data > TEMP_THR){
		    		temp_flag = WARNING;
		    	}

		    	//Read Accelerometer
		    	BSP_ACCELERO_AccGetXYZ(accel_data_i16);		// read accelerometer
		    	// the function above returns 16 bit integers which are 100 * acceleration_in_m/s2. Converting to float to print the actual acceleration.
		    	// Divide values by 9.8 to convert to 'g'
		    	accel_data[0] = ((float)accel_data_i16[0] / 100.0f) / 9.8f;
		    	accel_data[1] = ((float)accel_data_i16[1] / 100.0f) / 9.8f;
		    	accel_data[2] = ((float)accel_data_i16[2] / 100.0f) / 9.8f;

		    	//Read Humidity in %RH
		    	hum_data = BSP_HSENSOR_ReadHumidity();
		    	if (hum_data < HUM_THR){
		    		hum_flag = WARNING;
		    	}

		    	// Read Pressure in Pascal
		    	p_data = BSP_PSENSOR_ReadPressure()*100.0f;
		    	if (p_data > P_THR ){
		    		p_flag = WARNING;
		    	}
		    	//Read Magnetometer
		    	BSP_MAGNETO_GetXYZ(mag_data_i16);
		        // convert magnetometer data in terms of gauss
		    	mag_data[0] = (float)mag_data_i16[0] / 1000.0f;
		    	mag_data[1] = (float)mag_data_i16[1] / 1000.0f;
		    	mag_data[2] = (float)mag_data_i16[2] / 1000.0f;
		    	//set initial position when first enering ICU mode
		    	if (mag_start == 0){
		    		mag_position[0] = mag_data[0];
		    		mag_position[1] = mag_data[1];
		    		mag_position[2] = mag_data[2];
		    	}
		    	//find shift in position
		    	for (int count=0; count<3; count++){
		    		mag_shift[count] = fabs(mag_position[count]-mag_data[count]); //use fabs to find absolute value of floating type data.
		    	}
		    	if (mag_shift[0]>MAG_THR || mag_shift[1]>MAG_THR || mag_shift[2]>MAG_THR){
		    		    		mag_flag = WARNING;
		    		    	}


		    	//Read Gyroscope
		    	BSP_GYRO_GetXYZ(gyro_data_i16);
		        // get gyro data in terms of dps.
		    	gyro_data[0] = (float)gyro_data_i16[0] / 1000.0f;
		    	gyro_data[1] = (float)gyro_data_i16[1] / 1000.0f;
		    	gyro_data[2] = (float)gyro_data_i16[2] / 1000.0f;
		    	//find combined actual rotation of gyroscope based on rotation angles X, Y, Z.
		    	gyro_combine = sqrt(pow(gyro_data[0],2)+pow(gyro_data[1],2)+pow(gyro_data[2],2));
		    	if (gyro_combine > GYRO_THR){
		    		gyro_flag = WARNING;
		    	}

		    	read_t1 = read_t2;
		    }
		    else {
		    	read_t2 = (HAL_GetTick());
		    }


		    /*Transmission to CHIPACU every 10s*/
		    if ((display_t2 - display_t1) > 10000){
		    	/*===WARNING MESSAGES SEND TO CHIPACU BEFORE READINGS======================*/
		    	 //Body temp too high
		    	if (temp_flag == WARNING){
		    		sprintf(message_print, "Fever is detected\r\n");
		    		HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	}
		    	//Falling detected
		    	if (accel_flag == WARNING){
		    	sprintf(message_print, "Falling is detected\r\n");
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	}
		    	//Respiratory problem
		    	if (hum_flag == WARNING || p_flag == WARNING){
		    	sprintf(message_print, "Check patient's breath!\r\n");
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	}
		    	//Orientation problem
		    	if (mag_flag == WARNING){
		    	sprintf(message_print, "Check patient's abnormal orientation!\r\n");
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	}
		    	//Pain problem
		    	if (gyro_flag == WARNING){
		    	sprintf(message_print, "Patient in pain!\r\n");
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);
		    	}


		    	/*========SCHEDULED SENSOR READINGS (ICU MODE ONLY)===================================*/
		    	sprintf(message_print,"%03d TEMP %0.2f(degreeC) ACC %0.2f(g) %0.2f(g) %0.2f(g)\r\n", counter, temp_data, accel_data[0], accel_data[1], accel_data[2]);
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

		    	sprintf(message_print, "%03d GYRO %0.1f(dps) MAGNETO %0.2f(G) %0.2f(G) %0.2f(G)\r\n", counter, gyro_combine, mag_data[0], mag_data[1], mag_data[2]);
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

		    	sprintf(message_print, "%03d HUMIDITY %0.2f(%RH) and PRESSURE %0.2f(Pa)\r\n",counter,  hum_data, p_data);
		    	HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print),0xFFFF);

		    	counter++;

		    	display_t1 = display_t2;
		    }

		    else {
		    	 display_t2 = HAL_GetTick();
		    }

}//while(1)
}//function

//Switch function for Pushbutton
void mode_switch(void){
	if (button_count == 0){
			button_count = 1;
			button_t1 = button_t2;
		}
		//timeout function for 0.5s
		else if(button_count >= 1){

		if ((button_t2 - button_t1) <= 500){
			flags_reset();
			HAL_NVIC_SystemReset();
		}
		if ((button_t2 - button_t1) > 500){
			button_count = 1;
			button_t1 = button_t2;
		}
	}
}

//Reset all flags when switching from ICU to Normal mode
void flags_reset(void){
	accel_flag = RESET;
	gyro_flag = RESET;
	p_flag = RESET;
	temp_flag = RESET;
	mag_flag = RESET;
	hum_flag = RESET;
}

//Configure interrupt for accelerometer sensor lsm6dsl
void accel_INT_CONFIG(void){
	uint8_t Buffer[1];
	Buffer[0] = 0x80; //set bit 7, 0b1000 0000
	SENSOR_IO_WriteMultiple(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_TAP_CFG1, Buffer, 1);
	Buffer[0] = 0x08; //FF_Dur [4:0] = 00001, FF_Ths [2:0] = 000
	SENSOR_IO_WriteMultiple(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_FREE_FALL, Buffer, 1);
	Buffer[0] = 0x10; // Drive FF interrupt to INT1 pin
	SENSOR_IO_WriteMultiple(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW, LSM6DSL_ACC_GYRO_MD1_CFG, Buffer, 1);
}


/* initialize peripherals for blinking LED */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitTypeDef GPIO_PushButton = {0};
  GPIO_InitTypeDef GPIO_lsm6dsl = {0};
  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();		//for LED2
  __HAL_RCC_GPIOC_CLK_ENABLE();		//for push button
  __HAL_RCC_GPIOD_CLK_ENABLE();		//for lsm6dsl
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LED2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOC, BUTTON_EXTI13_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOD, LSM6DSL_INT1_EXTI11_Pin, GPIO_PIN_RESET);
  //configure GPIO pin LED2_Pin
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  //configure GPIO pin BUT_EXTI13
  GPIO_PushButton.Pin = BUTTON_EXTI13_Pin;
  GPIO_PushButton.Mode = GPIO_MODE_IT_FALLING;
  GPIO_PushButton.Pull = GPIO_PULLUP;
  GPIO_PushButton.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_PushButton);
  //configure GPIO pin lsm6dsl
  GPIO_lsm6dsl.Pin = LSM6DSL_INT1_EXTI11_Pin;
  GPIO_lsm6dsl.Mode = GPIO_MODE_IT_RISING;
  GPIO_lsm6dsl.Pull = GPIO_PULLDOWN;
  GPIO_lsm6dsl.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_lsm6dsl);
  // Enable NVIC EXTI line 13
  	HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

//Executing interrupt
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	button_t2 = (HAL_GetTick());
	//for Pushbutton
	if (GPIO_Pin == BUTTON_EXTI13_Pin){
		mode_switch();
	}
	//for accelerometer, LSM6DSL sensor
	if(GPIO_Pin == LSM6DSL_INT1_EXTI11_Pin){
		uint8_t tmp;
		tmp = SENSOR_IO_Read(LSM6DSL_ACC_GYRO_I2C_ADDRESS_LOW+1, LSM6DSL_ACC_GYRO_WAKE_UP_SRC);
		tmp &= 0x20; //read bit[5] to determine if FF flag was raised by device
		if (tmp){
					accel_flag = WARNING;
		}
	}
}


//UART1
static void UART1_Init(void)
{
    /* Pin configuration for UART. BSP_COM_Init() can do this automatically */
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* Configuring UART1 */
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
      while(1);
    }
}
